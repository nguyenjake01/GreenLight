import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import 'bootstrap/dist/js/bootstrap.bundle.min';
import './App.css';
import HomePage from './pages/home';
import Services from './pages/services';
import Contact from './pages/contact';
import Footer from './components/Footer';
import Header from './components/Header';
import About from './pages/about'; // Assuming you have an About page

function App() {
  return (
    <Router>
      <div className="app-wrapper flex flex-col min-h-screen">
        {/* Header always visible */}
        <Header />

        {/* Main content */}
        <main className="flex-grow">
          <Routes>
            <Route path="/" element={<HomePage />} />
            <Route path="/services" element={<Services />} />
            <Route path="/contact" element={<Contact />} />
            <Route path="/about" element={<About />} />
            {/* Add more routes as needed */}
          </Routes>
        </main>

        {/* Footer always visible */}
        <Footer />
      </div>
    </Router>
  );
}

export default App;
