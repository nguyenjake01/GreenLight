import { Link } from "react-router-dom";

function Footer() {
    return (
        <footer className="bg-white mt-auto py-12 text-black border-t border-gray-200">
            <div className="max-w-6xl mx-auto px-4">
                {/* Top Row */}
                <div className="flex flex-col md:flex-row justify-between items-center border-b border-gray-200 pb-8 gap-6">
                    {/* Brand */}
                    <div className="text-2xl font-bold tracking-wide hover:text-green-600 transition-colors duration-300">
                        Care360 Nutrition
                    </div>

                    
                </div>

                {/* Bottom Links */}
                <div className="grid md:grid-cols-3 gap-12 mt-12">
                    <div>
                        <h3 className="font-bold text-green-700 mb-6">Quick Links</h3>
                        <ul className="space-y-2">
                            {[
                                { to: "/", text: "Home" },
                                { to: "/services", text: "Services" },
                                { to: "/contact", text: "Contact" }
                            ].map(({ to, text }) => (
                                <li key={to}>
                                    <Link
                                        to={to}
                                        className="relative group inline-block transition-all duration-300 hover:translate-x-1"
                                    >
                                        <span className="relative z-10">{text}</span>
                                        <span className="absolute bottom-0 left-0 w-full h-0.5 bg-green-600 transform scale-x-0 group-hover:scale-x-100 transition-transform duration-300 ease-out"/>
                                    </Link>
                                </li>
                            ))}
                        </ul>
                    </div>

                    <div>
                        <h3 className="font-bold text-green-700 mb-6">Our Mission</h3>
                        <p className="text-gray-700 text-sm leading-relaxed">
                            Providing innovative, customized nutrition care and dining solutions
                            that satisfy customers, promote health, and ensure every client
                            receives a high-quality dining experience.
                        </p>
                    </div>

                    <div>
                        <h3 className="font-bold text-green-700 mb-6">Contact Us</h3>
                        <p className="text-gray-700 text-sm">P.O. Box 4857 Diamond bar ca 91766</p>
                        <p className="text-gray-700 text-sm">Email: info@care360.com</p>
                        <p className="text-gray-700 text-sm">Phone: (626) 765-5208</p>
                    </div>
                </div>

                {/* Copyright */}
                <div className="text-center mt-12 text-gray-500 text-sm">
                    © {new Date().getFullYear()} Care360 Nutrition Therapy & Consulting. All rights reserved.
                </div>
            </div>
        </footer>
    );
}

export default Footer;
