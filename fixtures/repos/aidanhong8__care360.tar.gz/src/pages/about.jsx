import { motion } from 'framer-motion';
import { Parallax } from 'react-scroll-parallax';
export default function About() {
    const cards = [
    {
      title: "Our Story",
      text: "Founded in 2010, Care360 Nutrition Therapy and Consulting has grown into a full-spectrum nutrition consulting company throughout Southern California."
    },
    {
      title: "Our Expertise",
      text: "With 20+ years of combined experience, our registered dietitians are dedicated to delivering innovative, customized nutrition care."
    },
    {
      title: "Our Promise",
      text: "We provide dining solutions that satisfy customers, promote health, and ensure every client enjoys a high-quality dining experience."
    }
  ];

  return (
    <section className="bg-white py-20">
      <div className="max-w-6xl mx-auto px-6">
        <h2 className="text-4xl font-bold text-center mb-12">Who We Are</h2>

        {/* Intro paragraph */}
        <motion.p
          initial={{ opacity: 0, y: 40 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="text-lg text-gray-700 leading-relaxed text-center max-w-3xl mx-auto mb-16"
        >
          Care360 Nutrition Therapy and Consulting, founded in 2010, has expanded to be a all-rounded
          nutrition consulting company throughout Southern California. We have 20+ years combined
          experience and our registered dietitians are committed to providing innovative, customized,
          quality nutrition care and dining solutions that satisfy customers, promote health and wellness
          and ensure every client receives a high quality dining experience.
        </motion.p>

        {/* Parallax cards */}
        <div className="grid md:grid-cols-3 gap-10">
          {cards.map((card, i) => (
            <Parallax key={i} speed={i % 2 === 0 ? -10 : 10}>
              <motion.div
                initial={{ opacity: 0, y: 40 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8, delay: i * 0.2 }}
                className="bg-gray-50 p-6 rounded-xl shadow-lg hover:shadow-2xl transition"
              >
                <h3 className="text-xl font-semibold mb-3">{card.title}</h3>
                <p className="text-gray-600">{card.text}</p>
              </motion.div>
            </Parallax>
          ))}
        </div>
      </div>
    </section>
  );
}
