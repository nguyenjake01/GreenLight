import { motion } from 'framer-motion';

export default function Contact() {
  return (
    <section className="bg-white py-20">
      <div className="max-w-4xl mx-auto px-6">
        <h2 className="text-4xl font-bold text-center mb-10">Get in Touch</h2>
        <motion.form
          initial={{ opacity: 0, y: 40 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="grid gap-6"
        >
          <input type="text" placeholder="Name" className="border p-3 rounded-lg focus:outline-none focus:ring" />
          <input type="email" placeholder="Email" className="border p-3 rounded-lg focus:outline-none focus:ring" />
          <textarea placeholder="Your message" rows="5" className="border p-3 rounded-lg focus:outline-none focus:ring"></textarea>
          <button type="submit" className="bg-green-600 text-white py-3 px-6 rounded-lg hover:bg-green-700 transition">
            Send Message
          </button>
        </motion.form>
      </div>
    </section>
  );
}
