import { Parallax } from 'react-scroll-parallax';
import { motion } from 'framer-motion';
import homeimg from './home.jpg'

export default function Home() {
  return (
    <div className="overflow-hidden">
      {/* Hero Section */}
      <section className="relative h-screen flex items-center justify-center bg-gray-900 text-white">
        <Parallax speed={-20}>
          <img
            src="/images/hero-bg.jpg"
            alt="Healthy Lifestyle"
            className="absolute inset-0 w-full h-full object-cover opacity-70"
          />
        </Parallax>
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1 }}
          className="relative z-10 text-center"
        >
          <h1 className="text-5xl md:text-7xl font-bold">Care360</h1>
          <p className="mt-4 text-lg md:text-2xl">Taking CARE of your health and needs</p>
        </motion.div>
      </section>

      {/* About Section */}
      <section className="max-w-6xl mx-auto px-6 py-20 grid md:grid-cols-2 gap-12">
        <motion.img
          src={homeimg}
          alt="Nutrition Consultation"
          className="rounded-2xl shadow-lg"
          initial={{ opacity: 0, x: -50 }}
          whileInView={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.8 }}
        />
        <motion.div
          initial={{ opacity: 0, x: 50 }}
          whileInView={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.8 }}
        >
          <h2 className="text-3xl font-bold mb-4">Who We Are</h2>
          <p className="text-gray-700 leading-relaxed">
            We provide personalized nutrition therapy and consulting to help you achieve your health goals.
          </p>
        </motion.div>
      </section>
    </div>
  );
}
