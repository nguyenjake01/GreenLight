import { motion } from 'framer-motion';
import service1 from './service1.jpg';
import service2 from './service2.jpg';
import service3 from './service3.jpg';
import service4 from './service4.jpg';

const services = [
  {
    title: 'Individual Counseling',
    desc: `Do you have high blood pressure or cardiovascular disease? Do you want to feel and look better and lose those undesirable pounds? Are you concerned about the meal plan for your diabetes or gestational diabetes? Our Registered Dietitian will work together with your physician to provide you with the best care possible. No matter what your diet restrictions, your dietitian will help you coordinate them into your daily routine and provide continuous support and guidance.`,
    img: service1
  },
  {
    title: 'Healthcare Consulting',
    desc: `We offer a variety of services to assist you in the management of your dining and nutritional cares. From menu planning to recipe nutritional analysis, we can help and provide what you requested within a reasonable time. Our team of experts stays up-to-date with regulations to help ensure your facility's compliance with governing agencies including CMS, DHS, TJC, state, and county. We can come to your facility and help you get prepared.`,
    img: service2
  },
  {
    title: 'Corporate Wellness',
    desc: `Do you know employee satisfaction is directly linked to resident satisfaction? Do you want your staff to stay healthy and increase their productivity? Our Registered Dietitians are available to teach nutrition and weight management classes, implement wellness programs, or work individually with your staff to help them achieve their nutrition or weight goals.`,
    img: service3
  },
  {
    title: 'Staffing Needs',
    desc: `Are you frustrated in hiring the right person for your kitchen? Or do you need a dietitian on a per diem basis? We can assist you with any staffing needs — interim or permanent. Whether you need a Registered Dietitian, nutrition coordinator, or a food service supervisor, we can help.`,
    img: service4
  }
];

export default function Services() {
  return (
    <section className="bg-gray-50 py-20">
      <div className="max-w-6xl mx-auto px-6">
        <h2 className="text-4xl font-bold text-center mb-12">Our Services</h2>

        <div className="grid md:grid-cols-2 gap-10">
          {services.map((service, i) => (
            <motion.div
              key={i}
              className="bg-white rounded-2xl shadow-lg overflow-hidden hover:shadow-2xl transition"
              initial={{ opacity: 0, y: 50 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.2 }}
            >
              <img
                src={service.img}
                alt={service.title}
                className="h-56 w-full object-cover"
              />
              <div className="p-6">
                <h3 className="text-2xl font-bold mb-4">{service.title}</h3>
                <p className="text-gray-600 leading-relaxed">{service.desc}</p>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
